//******************************************************************************
//  Jose I Quinones
//  Texas Instruments Inc.
//  June 2009
//  Built with IAR Embedded Workbench Version: 3.42A
//******************************************************************************
#include "Config.h"

int StatusLED;
char AccelerateState;
unsigned int SteppingRate, SteppingRateTMR, StartingSpeed, StoppingSpeed, DesiredStepperSpeed;
unsigned int AccelRate, tmpAccelTimeBaseScale, AccelTimeBaseScale, AccelTimeBaseTMR, AccelerationIncrease;
unsigned int StepsToStop, StepsToMove, tmpStepsToMove;
bool MoveSteps, AccelerateTrue;

void Task0(void)
{

if (AccelerateTrue)
  {
    AccelDecel();
  }

StatusLED += 1;
if (!StatusLED)
    {
    P3OUT ^= StatusLEDPin;
    }

if (MessageComplete)
    {
      SerialOutBuffer[0] = FIRMWARE_REVISION;
      SerialOutBuffer[1] = 0;
      SerialOutBuffer[2] = 0;
      switch(OPCODE)
      {

// Write GPIO Data [ OPCODE = 3 ] [ P1OUT DATA ] [ P4OUT Data ] [ Not Used ] [ Not Used ]
// GPIO DATA = P13/P12/P11/P10/P47/P46/P45/P44
      case (WRITE_GPIO):

            P1OUT = SerialBuffer[1];
            P4OUT = SerialBuffer[2];

            SerialOutBuffer[1] = ~SerialBuffer[1];
            break;
// DAC 0 Config and Write [ OPCODE = 5 ] [ Config HB ] [ Config LB ] [ Data HB ] [ Data LB ]
      case (DAC0_UPDATE):
            DAC12_0CTL = 0;
            DAC12_0CTL = (SerialBuffer[1] * 256) + SerialBuffer[2];
            DAC12_0DAT = (SerialBuffer[3] * 256) + SerialBuffer[4];
            break;
// DAC 1 Config and Write [ OPCODE = 6 ] [ Config HB ] [ Config LB ] [ Data HB ] [ Data LB ]
      case (DAC1_UPDATE):
            DAC12_1CTL = 0;
            DAC12_1CTL = (SerialBuffer[1] * 256) + SerialBuffer[2];
            DAC12_1DAT = (SerialBuffer[3] * 256) + SerialBuffer[4];
            break;

// Configure HB_MODE [ OPCODE = 0x0A ] [HB MODE] [ Not Used ] [ Not Used ] [ Not Used ]
      case (HB_MODE):
            if (SerialBuffer[1])
              {
//            TBCTL |= TB_CNTL_08;                //Configure Timer to run up to FF (8 bit FRC) - 8 bit PWM Mode
            // Modified by JC, June 20, 2013: Use up mode with free running counter for PWM
              TBCTL = 0x0110;
              TBR = 0;
              P4SEL |= AIN2;                      //AIN2_DIR Pin is Peripheral
              TBCCR0 = 0x100;
              }
            else
              {
              TBCTL &= ~TB_CNTL_08;               //Configure Timer to run up to FFFF (16 bit FRC)
              P4SEL &= ~AIN2;                     //AIN2_DIR Pin is GPIO
              TBCCTL1 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
              TBCCTL2 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
              TBCCTL3 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
              TBCCTL4 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0

              }
        break;

// Enable PWM [ OPCODE = 0x0B ] [ Timer # ] [ Duty Cycle ] [ Not Used ] [ Not Used ]
      case (ENABLE_PWM):
        int tempOut;
        switch (SerialBuffer[1])
        {
        case 1:
            TBCCR1 = SerialBuffer[2];
            tempOut = TBCCTL1;
            tempOut &= 0xFF1F;                // Clear OUTMODx bits; 3 MSB on lower byte
            tempOut |= TB_OUTMOD_RESSET;
            TBCCTL1 = tempOut;
        break;
        case 2:
            TBCCR2 = SerialBuffer[2];
            tempOut = TBCCTL2;
            tempOut &= 0xFF1F;                // Clear OUTMODx bits; 3 MSB on lower byte
            tempOut |= TB_OUTMOD_RESSET;
            TBCCTL2 = tempOut;
        break;
        case 3:
            TBCCR3 = SerialBuffer[2];
            tempOut = TBCCTL3;
            tempOut &= 0xFF1F;                // Clear OUTMODx bits; 3 MSB on lower byte
            tempOut |= TB_OUTMOD_RESSET;
            TBCCTL3 = tempOut;
        break;
        case 4:
            TBCCR4 = SerialBuffer[2];
            tempOut = TBCCTL4;
            tempOut &= 0xFF1F;                // Clear OUTMODx bits; 3 MSB on lower byte
            tempOut |= TB_OUTMOD_RESSET;
            TBCCTL4 = tempOut;
        break;
        }
      break;
// Disable PWM [ OPCODE = 0x0C ] [ Timer # ] [ Not Used ] [ Not Used ] [ Not Used ]
      case (DISABLE_PWM):

        switch (SerialBuffer[1])
        {
        case 1:
            TBCCTL1 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
          break;
        case 2:
            TBCCTL2 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
          break;
        case 3:
            TBCCTL3 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
          break;
        case 4:
            TBCCTL4 &= 0xFF1B;                // Clear OUTMODx bits and OUT bit; Configures the PWM output to OUTx value, in this case 0
          break;
        }
      break;

// Pulse Timer Output [ OPCODE = 0x0F ] [Timer Used] [ Pulse Length Hi ] [ Pulse Length Lo ] [ Not Used ]
      case (PULSE_TMR):
        TBCTL &= ~TB_CNTL_08;                //Configure Timer to run up to FFFF (16 bit FRC)
        switch (SerialBuffer[1])
        {
        case 1:
            TBCCTL1 &= 0xFF1F;                                          // Clear OUTMODx bits; 3 MSB on lower byte; Timer configured to output mode
            TBCCTL1 |= TB_OUT_HIGH;                                     //Set the output (pulse start)
            TBCCTL1 |= TB_OUTMOD_RESET;                                 //Configure the timer to reset
            TBCCR1 = TBR + ((SerialBuffer[2] * 256) + SerialBuffer[3]); //Configure the pulse reset time (pulse end)
          break;
        }
        break;
// START STEPPER [ OPCODE = 0x12 ] [ Frequency Hi ] [ Frequency Lo ] [ Accel Rate ] [ Accel Time Base ]
      case (START_STEPPER):
            TBCCTL1 &= 0xFF1F;                                          // Clear OUTMODx bits; 3 MSB on lower byte; Timer configured to output mode
            TBCCTL1 |= TB_OUTMOD_SETRES + CCIE;                         //Configure the timer to SET. TBCCR0 does the reset
            DesiredStepperSpeed = (SerialBuffer[1] * 256) + SerialBuffer[2];   //Configure the Frequency Rate
            AccelRate = (SerialBuffer[3] * 256) + SerialBuffer[4];

            SteppingRate = StartingSpeed;
            SteppingRateTMR = PPS2Timer(StartingSpeed);
            TBCCR1 = SteppingRateTMR;
            AccelerateState = ACCEL;
            AccelerationCompute(AccelRate);
        break;
// STOP STEPPER [ OPCODE = 0x13 ] [ Frequency Hi ] [ Frequency Lo ] [ Not Used ] [ Not Used ]
      case (STOP_STEPPER):
            AccelRate = (SerialBuffer[3] * 256) + SerialBuffer[4];
            AccelerateState = STOP;
            DesiredStepperSpeed = StoppingSpeed;                               //Speed to stop at
            AccelerationCompute(AccelRate);
       break;
// STEPPER_SPEED [ OPCODE = 0x14 ] [ Frequency Hi ] [ Frequency Lo ] [ Accel Rate ] [ Accel Time Base ]
      case (STEPPER_SPEED):
            DesiredStepperSpeed = (SerialBuffer[1] * 256) + SerialBuffer[2];   //Configure the Frequency Rate
            AccelRate = (SerialBuffer[3] * 256) + SerialBuffer[4];

            if ((unsigned int)DesiredStepperSpeed > (unsigned int)SteppingRate)
            {
                AccelerateState = ACCEL;
            }
            else
            {
                AccelerateState = DECEL;
            }
            AccelerationCompute(AccelRate);
      break;
// MOVE_STEPS [ OPCODE = 0x15 ] [ Frequency Hi ] [ Frequency Lo ] [ Accel Rate Hi ] [ Accel Rate Lo ]
      case (MOVE_STEPS):
            TBCCTL1 &= 0xFF1F;                                          // Clear OUTMODx bits; 3 MSB on lower byte; Timer configured to output mode
            TBCCTL1 |= TB_OUTMOD_SETRES + CCIE;                         //Configure the timer to SET. TBCCR0 does the reset
            DesiredStepperSpeed = (SerialBuffer[1] * 256) + SerialBuffer[2];   //Configure the Frequency Rate
            AccelRate = (SerialBuffer[3] * 256) + SerialBuffer[4];
            SteppingRate = StartingSpeed;
            SteppingRateTMR = PPS2Timer(StartingSpeed);
            TBCCR1 = SteppingRateTMR;
            AccelerateState = ACCEL;
            tmpStepsToMove = 0;
            MoveSteps = true;
            AccelerationCompute(AccelRate);
            break;
// STEPPER_CONFIG [ OPCODE = 0x16 ] [ Frequency Hi ] [ Frequency Lo ] [ Not Used ] [ Not Used ]
      case (STEPPER_CONFIG):
            StartingSpeed = (SerialBuffer[1] * 256) + SerialBuffer[2];   //Configure the Frequency Rate
            StoppingSpeed = (SerialBuffer[3] * 256) + SerialBuffer[4];   //Configure the Frequency Rate
            break;
// CONFIG_STEPS [ OPCODE = 0x18 ] [ Number Of Steps Hi] [ Number Of Steps Lo] [ Steps to Stop Hi] [ Steps to Stop Lo]
      case (CONFIG_STEPS):
            StepsToMove = (SerialBuffer[1] * 256) + SerialBuffer[2];   //Configure the Frequency Rate
            StepsToStop = (SerialBuffer[3] * 256) + SerialBuffer[4];   //Configure the Frequency Rate
            break;

// Gort SPI [Opcode = 0x20 ] [ NU ] [ Data 24] [ Data 16 ] [ Data 8 ]

      case (GORT_SPI):
            int i,j,x;                // RLD 040113 added int j for added setup and hold
            unsigned long SerialOut;

            //DCOCTL = CALDCO_8MHZ;
            //BCSCTL1 = CALBC1_8MHZ + DIVA_CONF + XTS_CONF;// + XT2OFF_CONF;
            //BCSCTL2 = SELM_CONF + DIVM_DIV8 + SELS_CONF + DIVS_CONF + DCOR_CONF;  //Slow Main Clock During SPI actuation

            P5OUT &= ~SCLK;
            P5OUT |= SLAVE_SEL;
            for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- delay for Select

            SerialOut = 0;

            for (x = 0; x < 2; x++) // RLD 040213 -- temp change to 2, 16 bit write (was 3)
              {
              for (i = 7; i >= 0; i--)
                {
//              P5OUT &= ~SCLK;   // RLD 040113 -- commented out since the neg edge was moved to end
                for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- added setup time
                if (SerialBuffer[2 + x] & (1<<i))
                  {
                  P5OUT |= MOSI;
                  }
                else
                  {
                  P5OUT &= ~MOSI;
                  }
                for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- added setup time
                SerialOut = SerialOut << 1; // RLD 040113 -- to prevent shift of last read place here
                if (P5IN & MISO)
                  {
                    SerialOut ++;
                  }
                P5OUT |= SCLK;
                for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- added hold time
                P5OUT &= ~SCLK;            // RLD 040113 -- drop SCLK
                for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- delay for data valid
                }
              }
              P5OUT &= ~SCLK;
              for (j = 0; j < 4; j++) {__no_operation();} // RLD 040113 -- delay for data valid
              P5OUT &= ~SLAVE_SEL;

//          SerialOut = SerialOut >> 8;   // 040213 removed since only 16 bits are transferred
            SerialOutBuffer[1] = (SerialOut & 0xFF00 ) >> 8;
            SerialOutBuffer[2] = SerialOut & 0xFF;

            //BCSCTL2 = SELM_CONF + DIVM_DIV2 + SELS_CONF + DIVS_CONF + DCOR_CONF;
            //BCSCTL1 = CALBC1_16MHZ + DIVA_CONF + XTS_CONF;// + XT2OFF_CONF;
            //DCOCTL = CALDCO_16MHZ;

            break;

// Read Memory [Opcode = 0xE0 ] [ Address Hi ] [ Address Lo ] [ Not Used ] [ Not Used ]
      case (READ_MEM):
       int * MyPointer;
       int Address;

       Address = (SerialBuffer[1]*256 + SerialBuffer[2]);
       MyPointer = (int *) Address;
       SerialOutBuffer[1] = (*MyPointer & 0xFF00) >> 8;
       SerialOutBuffer[2] = (*MyPointer & 0xFF);
      break;
// Write Memory [Opcode = 0xE1 ] [ Address Hi ] [ Address Lo ] [ Data Hi ] [ Data Lo ]
      case (WRITE_WMEM):
        int Data;

        Address = (SerialBuffer[1]*256 + SerialBuffer[2]);
        Data = (SerialBuffer[3]*256 + SerialBuffer[4]);
        MyPointer = (int *) Address;
        *MyPointer = Data;
        break;

// Write Byte Memory [Opcode = 0xE2 ] [ Address ] [ Address Lo ] [ Data ] [Not Used ]
      case (WRITE_BMEM):
        char BData;
        char * MyPtr;

        Address = (SerialBuffer[1]*256 + SerialBuffer[2]);
        BData = SerialBuffer[3];
        MyPtr = (char *) Address;
        *MyPtr = BData;
        break;

      case (RESET_MCU):
        WDTCTL = 0x00;
        break;
      }
    MessageComplete = false;
    SerialOutPointer = 0;
    UCA0TXBUF = SerialOutBuffer[SerialOutPointer];
    IE2 |= UCA0TXIE;
    }
}

unsigned int PPS2Timer (unsigned int PPSValue)
  {
  int TimerValue;
  TimerValue = MAIN_CLK_MHZ/PPSValue;
  return TimerValue;
  }

void AccelerationCompute (unsigned int AccelRate)
  {
  if (AccelRate >= ACCEL_INCREASE_1)
    {
    AccelTimeBaseTMR = MAIN_CLK_MHZ/AccelRate;
    AccelTimeBaseScale = 1;
    }
  else if (AccelRate >= ACCEL_INCREASE_2)
    {
    AccelTimeBaseTMR = HALF_MAIN_CLK_MHZ/AccelRate;
    AccelTimeBaseScale = 2;
    }
  else if (AccelRate >= ACCEL_INCREASE_4)
    {
    AccelTimeBaseTMR = QUAD_MAIN_CLK_MHZ/AccelRate;
    AccelTimeBaseScale = 4;
    }
  else if (AccelRate >= ACCEL_INCREASE_8)
    {
    AccelTimeBaseTMR = EIGHT_MAIN_CLK_MHZ/AccelRate;
    AccelTimeBaseScale = 8;
    }
  else
    {
    AccelTimeBaseTMR = 50000;
    AccelTimeBaseScale = 16;
    }
  tmpAccelTimeBaseScale = AccelTimeBaseScale;
  AccelerationIncrease = 1;
  TACCR2 = TAR + AccelTimeBaseTMR;
  TACCTL2 |= CCIE;
  }

void AccelDecel ()
{
  AccelerateTrue = false;
  switch (AccelerateState)
  {
  case (ACCEL):
    tmpAccelTimeBaseScale -= 1;                  //Wait until delay expires
    if (tmpAccelTimeBaseScale <= 0)
        {
        if ((unsigned int) SteppingRate + (unsigned int) AccelerationIncrease > (unsigned int)DesiredStepperSpeed)
        {
          SteppingRateTMR = PPS2Timer(DesiredStepperSpeed);
          TACCTL2 &= ~CCIE;
        }
        else
        {
          SteppingRate += AccelerationIncrease;
          SteppingRateTMR = PPS2Timer(SteppingRate);
        }
        tmpAccelTimeBaseScale = AccelTimeBaseScale;
        TACCR2 += AccelTimeBaseTMR;
        }
    break;

  case (DECEL):
    tmpAccelTimeBaseScale -= 1;                  //Wait until delay expires
    if (tmpAccelTimeBaseScale <= 0)
        {
        if (((unsigned int) SteppingRate - (unsigned int) AccelerationIncrease) < DesiredStepperSpeed)
          {
          SteppingRateTMR = PPS2Timer(DesiredStepperSpeed);
          TACCTL2 &= ~CCIE;
          }
        else
          {
          SteppingRate -= AccelerationIncrease;
          SteppingRateTMR = PPS2Timer(SteppingRate);
          }
        tmpAccelTimeBaseScale = AccelTimeBaseScale;
        TACCR2 += AccelTimeBaseTMR;
        }
    break;

  case (STOP):
    tmpAccelTimeBaseScale -= 1;                  //Wait until delay expires
    if (tmpAccelTimeBaseScale <= 0)
        {
        if (((unsigned int) SteppingRate - (unsigned int) AccelerationIncrease) < DesiredStepperSpeed)
          {
          TBCCTL1 &= 0xFF0F;                                          //Disable CC and Interrupt
          TACCTL2 &= ~CCIE;
          }
        else
          {
          SteppingRate -= AccelerationIncrease;
          SteppingRateTMR = PPS2Timer(SteppingRate);
          }
        tmpAccelTimeBaseScale = AccelTimeBaseScale;
        TACCR2 += AccelTimeBaseTMR;
        }
    break;

  case (STEPS_STOP):
    tmpAccelTimeBaseScale -= 1;                  //Wait until delay expires
    if (tmpAccelTimeBaseScale <= 0)
        {
        if (((unsigned int) SteppingRate - (unsigned int) AccelerationIncrease) < DesiredStepperSpeed)
          {
          SteppingRateTMR = PPS2Timer(DesiredStepperSpeed);
          TACCTL2 &= ~CCIE;
          }
        else
          {
          SteppingRate -= AccelerationIncrease;
          SteppingRateTMR = PPS2Timer(SteppingRate);
          }
        tmpAccelTimeBaseScale = AccelTimeBaseScale;
        TACCR2 += AccelTimeBaseTMR;
        }
    break;
  }
}
